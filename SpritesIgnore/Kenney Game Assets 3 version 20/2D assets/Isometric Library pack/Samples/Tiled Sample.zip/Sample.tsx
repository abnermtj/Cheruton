<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="2018.12.22" name="Sample" tilewidth="256" tileheight="512" tilecount="11" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="12">
  <image width="256" height="512" source="Sprites/crate_E.png"/>
 </tile>
 <tile id="13">
  <image width="256" height="512" source="Sprites/doorway_E.png"/>
 </tile>
 <tile id="14">
  <image width="256" height="512" source="Sprites/fence_W.png"/>
 </tile>
 <tile id="15">
  <image width="256" height="512" source="Sprites/floor_E.png"/>
 </tile>
 <tile id="16">
  <image width="256" height="512" source="Sprites/stairs_E.png"/>
 </tile>
 <tile id="17">
  <image width="256" height="512" source="Sprites/stairs_S.png"/>
 </tile>
 <tile id="18">
  <image width="256" height="512" source="Sprites/stairsCornerOuter_S.png"/>
 </tile>
 <tile id="19">
  <image width="256" height="512" source="Sprites/switchFloorOn_E.png"/>
 </tile>
 <tile id="20">
  <image width="256" height="512" source="Sprites/wall_E.png"/>
 </tile>
 <tile id="21">
  <image width="256" height="512" source="Sprites/wallCurve_S.png"/>
 </tile>
 <tile id="22">
  <image width="256" height="512" source="Sprites/window_S.png"/>
 </tile>
</tileset>
